from flask import Blueprint
from datetime import datetime, timedelta
from opensearchpy import OpenSearch
# Create a Blueprint instance
from flask import jsonify
admin_api = Blueprint('admin', __name__)

USER_NAME = "Lavkus"
PASSWORD = "Lavkus@#1212"
HOST_URL="https://search-scraping-data-sqjdyrnbfijveyo3fr3lc6y24m.ap-south-1.es.amazonaws.com"

client = OpenSearch(
    hosts=[HOST_URL],
    http_auth=(USER_NAME, PASSWORD),
)


@admin_api.route('/')
def admin_home():
    return 'Hello from home admin!'

@admin_api.route('/print')
def admin_print_route():
    now = datetime.now()
    followers = 274150000
    formatted_date = now.strftime('%Y-%m-%d')
    doc = {
        formatted_date: {
            "followers": followers
        }
    }
    username = "virat.kohli"
    followers_trends = client.update(
        index='followers_trends',
        id=username,  
        body={
            "doc": doc,
            "doc_as_upsert": True
        }
    )

    print(f"followers_trends  {followers_trends}")
    return 'Hi Admin, I am from Noida'

@admin_api.route('/get_followers_trends')
def get_followers_trends():
    username = "virat.kohli"

    try:
        response = client.get(
            index='followers_trends',
            id=username
        )
        trends_data = response.get('_source', {})

        return jsonify({
            "status": "success",
            "username": username,
            "trends": trends_data
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
