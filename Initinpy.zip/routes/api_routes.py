from flask import Blueprint
from opensearchpy import OpenSearch, NotFoundError

api_bp = Blueprint('api', __name__)

@api_bp.route('/')
def home():
    try:
        
        # updated_docs = []
        # usernames = [
          
        # ]

        # for user in usernames:

        #     resp = client.search(
        #         index="discovery_data",
        #             body={
        #                 "query": {
        #                     "match": {
        #                         "handle": user
        #                     }
        #                 }
        #             }
        #     )

        #     hits = resp["hits"]["hits"][0]
            
        #     doc_id = hits["_id"]
        #     source = hits["_source"]

        #     if source.get("gender", "") == "male":
        #         # ✅ Update in DB to Entrepreneurship
        #         client.update(
        #             index="discovery_data",
        #             id=doc_id,
        #             body={
        #                 "doc": {
        #                     "gender": "female"
        #                 }
        #             }
        #         )
        #         source["gender"] = "female"

        #         updated_docs.append(source)

        # return {"updated": updated_docs}, 200
        return "I am from api"

    except Exception as e:
        return {"error": str(e)}, 500


@api_bp.route('/print')
def print_route():
        return 'I am from the Noida'
