def greet():
    return "Hello from module1"
