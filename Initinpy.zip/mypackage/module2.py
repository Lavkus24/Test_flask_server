def welcome():
    return "Welcome from module2"
