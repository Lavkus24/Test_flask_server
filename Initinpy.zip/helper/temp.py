def print_name():
    print("lavkus Yadav")
    return "Hello Lavkus I am from Noida"


def hello_world():
    return 'Hello World'
